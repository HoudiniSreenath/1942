using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace _1942
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Rectangle player;
        Rectangle cover;
        Texture2D playert;
        Texture2D black;
        string tittle;
        string playMsg;
        int playerSpeed;
        int screenHeight;
        int screenWidth;
        int roll;
        SpriteFont titlef;
        SpriteFont basic;
        Boolean Invulnerable;
        enum gamestate { start, play, quit };
        gamestate state;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            Invulnerable = false;
            screenWidth = graphics.GraphicsDevice.Viewport.Width;
            screenHeight = graphics.GraphicsDevice.Viewport.Height;
            player = new Rectangle(350, 350, 50, 50);
            cover = new Rectangle(0, 0, screenWidth, screenHeight);
            playerSpeed = 5;
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            playert = Content.Load<Texture2D>("player");
            black = Content.Load<Texture2D>("black");
            titlef = this.Content.Load<SpriteFont>("title");
            basic = this.Content.Load<SpriteFont>("basic");
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            KeyboardState kb = Keyboard.GetState();
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || kb.IsKeyDown(Keys.Escape))
                this.Exit();
            // TODO: Add your update logic here
            switch (state)
            {
                case gamestate.start:
                    tittle = "1942";
                    playMsg = "Press 'F' to Play";
                    if (kb.IsKeyDown(Keys.F))
                    {
                        state = gamestate.play;
                    }

                    break;
                case gamestate.play:
                    tittle = "";
                    playMsg = "";
                    
                    cover.X =+ screenWidth;
                    if (kb.IsKeyDown(Keys.S))
                    {
                        player.Y += playerSpeed;
                    }
                    if (kb.IsKeyDown(Keys.W))
                    {
                        player.Y -= playerSpeed / 2;
                    }
                    if (kb.IsKeyDown(Keys.A))
                    {
                        player.X -= playerSpeed;
                    }
                    if (kb.IsKeyDown(Keys.D))
                    {
                        player.X += playerSpeed;
                    }
                    if(kb.IsKeyDown(Keys.F))
                    {
                        Invulnerable = true;
                    }
                    break;
                case gamestate.quit:
                    break;
            }
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            Vector2 tittleVector = new Vector2(275, 125);
            Vector2 lowerMid = new Vector2(275, 275);
            // TODO: Add your drawing code here
            spriteBatch.Begin();
            spriteBatch.Draw(playert, player, Color.White);
            spriteBatch.Draw(black, cover, Color.Black);
            spriteBatch.DrawString(titlef, tittle, tittleVector, Color.Green);
            spriteBatch.DrawString(basic, playMsg, lowerMid, Color.Yellow);
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
