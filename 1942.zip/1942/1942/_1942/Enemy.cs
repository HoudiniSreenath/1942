﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace _1942
{
    class Enemy
    {
        int hp;
        int move;
        int mcd;
        int tcd;
        Rectangle plane;
        Boolean triggered;
        Random r = new Random();
        public Enemy(int hp, int move, int mcd, int tcd, Boolean triggered, Rectangle plane)
        {
            this.hp = hp;
            this.move = move;
            this.mcd = mcd;
            this.tcd = tcd;
            this.triggered = triggered;
            this.plane = plane;

        }


        public int gethp()
        {
            return hp;
        }

        public void isHit()
        {
            hp--;
        }

        public void settcd()
        {
            tcd = 20;
        }

        public void cdtcd()
        {
            tcd--;
        }
        public void cdmcd()
        {
            mcd--;
        }

        public void setmcd()
        {
            mcd = 60;
        }

        public int gettcd()
        {
            return tcd;
        }

        public int getmcd()
        {
            return mcd;
        }

        public int getMove()
        {
            move = r.Next(3);
            return move;
        }

        public Rectangle eplane()
        {
            return plane;
        }
        public void callMethod()
        {

            if (plane.X+50 < 800 && move==0)
            {
                plane.X += 5;
            }
            if (plane.X + 50 > 800 &&  move == 0)
            {
                move = 1;
            }
            if (plane.X > 0 && move == 1)
            {
                plane.X -= 5;
            }

            if (plane.X == 0 && move == 1)
            {
                move = 0;
            }
        }
        
        public Boolean isTriggered()
        {
            int trigger = r.Next(1000);
            if(trigger == 0)
            {
                triggered = true;
                return triggered;            
            }
            triggered = false;
            return triggered;
        }

    }
}
