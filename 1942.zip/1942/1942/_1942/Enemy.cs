﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace _1942
{
    class Enemy
    {
        int hp;
        int move;
        int mcd;
        int tcd;
        int size;
        Rectangle plane;
        Boolean triggered;
        Random r = new Random();

        public Enemy(int hp, int move, int mcd, int tcd, Boolean triggered, int size, Rectangle plane)
        {
            this.hp = hp;
            this.move = move;
        }

        public int gethp()
        {
            return hp;
        }

        public void isHit()
        {
            hp--;
        }

        public void settcd()
        {
            tcd = 20;
        }

        public void cdtcd()
        {
            tcd--;
        }
        public void cdmcd()
        {
            mcd--;
        }

        public void setmcd()
        {
            mcd = 60;
        }

        public int gettcd()
        {
            return tcd;
        }

        public int getmcd()
        {
            return mcd;
        }

        public int getMove()
        {
            move = r.Next(3);
            return move;
        }

        public Rectangle eplane()
        {
            return plane;
        }

        public Boolean isTriggered()
        {
            int trigger = r.Next(21);
            if(trigger == 0)
            {
                triggered = true;
                return triggered;            
            }
            triggered = false;
            return triggered;
        }

    }
}
